def python_helloworld():
	print("Hello World! (python)")
	print("updated")
#	print("Enter input",end=":")
#	a = input()
#	print(a)
